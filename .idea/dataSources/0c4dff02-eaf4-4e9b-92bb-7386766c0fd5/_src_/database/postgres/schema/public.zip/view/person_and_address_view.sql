CREATE VIEW person_and_address_view AS
SELECT person.id AS person_id,
    person.firstname,
    person.lastname,
    address.id AS address_id,
    address.street,
    address.zip_code,
    address.city
   FROM (person
     LEFT JOIN address ON ((person.id = address.person_id)))