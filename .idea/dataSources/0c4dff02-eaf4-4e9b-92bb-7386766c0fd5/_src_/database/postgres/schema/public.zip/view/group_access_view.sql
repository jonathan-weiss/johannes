CREATE VIEW group_access_view AS
WITH RECURSIVE search_group(member_guid, group_guid, access_level) AS (
         SELECT gm.member_guid,
            gm.group_guid,
            gm.access_level
           FROM group_membership gm
        UNION ALL
         SELECT gm2.member_guid,
            sg_1.group_guid,
            LEAST(gm2.access_level, sg_1.access_level) AS "least"
           FROM search_group sg_1,
            group_membership gm2
          WHERE (gm2.group_guid = sg_1.member_guid)
        )
 SELECT DISTINCT ON (sg.group_guid, sg.member_guid) sg.member_guid,
    sg.group_guid,
    sg.access_level
   FROM search_group sg
  ORDER BY sg.group_guid, sg.member_guid, sg.access_level DESC