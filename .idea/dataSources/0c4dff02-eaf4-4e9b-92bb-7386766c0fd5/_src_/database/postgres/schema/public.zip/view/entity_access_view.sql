CREATE VIEW entity_access_view AS
SELECT DISTINCT ON (entity_access.entity_guid, COALESCE(group_access_view.member_guid, entity_access.accessor_guid)) entity_access.entity_guid,
    COALESCE(group_access_view.member_guid, entity_access.accessor_guid) AS accessor_guid,
    max(LEAST(group_access_view.access_level, entity_access.access_level)) AS access_level
   FROM (entity_access
     LEFT JOIN group_access_view ON ((entity_access.accessor_guid = group_access_view.group_guid)))
  GROUP BY group_access_view.member_guid, entity_access.accessor_guid, entity_access.entity_guid
  ORDER BY entity_access.entity_guid, COALESCE(group_access_view.member_guid, entity_access.accessor_guid), max(LEAST(group_access_view.access_level, entity_access.access_level))